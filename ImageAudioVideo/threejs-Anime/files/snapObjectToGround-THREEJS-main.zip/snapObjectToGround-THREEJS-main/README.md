# snapObjectToGround-THREEJS
In this repo, I have added function to snap object to group in three js.


# Demo
 run `SnapObjectToGround.html`